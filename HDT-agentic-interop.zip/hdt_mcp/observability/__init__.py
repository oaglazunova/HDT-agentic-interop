"""
Observability utilities (telemetry, metrics) for HDT MCP.
"""
