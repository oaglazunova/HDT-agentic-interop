"""
HTTP utilities for HDT MCP.

Provides a small, dependency-free client wrapper with optional caching and
retry logic, driven by a caller-provided headers function.
"""
